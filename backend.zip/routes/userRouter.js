const express = require("express");
const user = require("../model/userSchema");
const Router = express.Router();
const { register, loginUser } = require("../controller/authController");
const getUser = require("../controller/userController");
const { authenticateToken } = require("../utils/jwt");


Router.get("/getUser", authenticateToken, async (request, response) => {
  const result = await getUser(request);
  return response.json(result);
});

Router.post("/register", register);

Router.post("/login", async (req, res) => {
  const result = await loginUser(req);
  return res.json(result);
});

module.exports = Router;
