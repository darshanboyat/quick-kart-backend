const user = require("../model/userSchema");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const passport = require("passport")
const ExpressError = require("../utils/errorGenerator.js");
const { generateAccessToken } = require("../utils/jwt");

const register = async (req, res, next) => {
  try {
    let hashedPassword = await bcrypt.hash(req.body.password, 10);

    let createUser = new user({
      name: req.body.name,
      phone: req.body.phone,
      email: req.body.email,
      permanentaddress: req.body.permanentaddress,
      gender: req.body.gender,
      password: hashedPassword,
    });

    await createUser.save();

    res.status(201).send(createUser);
  } catch (err) {
    res.status(400).send("User not created");
  }
};

// const login = async (req, res, next) => {
//   try {
//     var username = req.body.email;
//     var password = req.body.password;

//     const foundUser = await user.findOne({
//       email: username,
//     });

//     if (!foundUser) throw new Error("User not found");

//     const isMatch = await bcrypt.compare(password, foundUser.password);

//     if (!isMatch) throw new Error("Sorry! Incorrect email or password");

// const token = jwt.sign({ _id: foundUser._id.toString() }, "darshanboyat");

// foundUser.token = token;
// await foundUser.save();

//     res.status(200).send(foundUser);
//   }
//   catch (err) {
//     res.status(500).send("Something went wrong");
//   }
// };




// const PostLogin = async (req, res, next) => {

//   let result = user.find((user) => user.email == req.body.email);

//   if (user) 
//   {
//     const passwordCheck = await bcrypt.compare(req.body.password, result.password);
//     if (passwordCheck) 
//     {

//       const token = jwt.sign({ _id: result._id.toString() }, "darshanboyat");
//       result.token = token;
//       await result.save();

//       res.status(200).send({
//         message: "Successfully Logined....",
//       });
//     } else {
//       res.status(401).send({
//         message: "Password Incorrect!!!",
//       });
//     }
//   } else {
//     res.status(501).send({
//       message: "User Not Found!!!!",
//     });
//   }
// };


const loginUser = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return new ExpressError(
      401,
      "Either username or password is missing in the request."
    );
  }
  const userData = await user.findOne({
    email: req.body.email,
  });
  if (!userData) {
    return new ExpressError(404, "email not found in the database.");
  }
  const match = bcrypt.compareSync(req.body.password, userData.password);
  if (!match) {
    return new ExpressError(403, "Invalid password");
  }
  
  const token = generateAccessToken({ _id: userData._id });
  return {
    error: false,
    sucess: true,
    message: "login user successfully",
    data: userData,
    token,
  };
};


module.exports = {
  register,
  // login,
  loginUser,
};
